#ifndef TITLE_H_INCLUDED
#define TITLE_H_INCLUDED

#include "demo.h"

int title_screen(void);
void end_title(void);

#endif
